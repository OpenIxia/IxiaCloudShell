configure:
update the config.json file

run:
python pyces.py config.json

